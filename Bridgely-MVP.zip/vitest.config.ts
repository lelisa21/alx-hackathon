import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    include: [
      "tests/**/*.test.ts",
      "packages/**/*.test.ts",
      "scripts/**/*.test.mjs",
    ],
    environment: "node",
  },
});
