import { describe, expect, it, vi } from "vitest";
import { parseConfig } from "../src/config.js";
import { createApiProviderRuntime } from "../src/provider-runtime.js";
import { loadPacks } from "@bridgely/locales-tools";
import { resolve } from "node:path";

const secrets = [
  Buffer.alloc(32, 4).toString("base64"),
  Buffer.alloc(32, 5).toString("base64"),
  Buffer.alloc(32, 6).toString("base64"),
];

const baseEnvironment = {
  NODE_ENV: "test",
  DATABASE_URL: "postgres://dimts:password@localhost:5432/dimts",
 ENC_KEY: secrets[0],
 HASH_KEY: secrets[1],
 JWT_SECRET: secrets[2],
 CRON_SECRET: "a-cron-secret-that-is-long-enough",
};

const remoteProvider = {
  id: "groq-fast",
  adapter: "openai-compatible",
  model: "model-name",
  endpoint: "https://provider.example/v1",
  credentialRef: "TEST_LLM_CREDENTIAL",
  privacyClass: "remote",
  enabled: true,
  priority: 10,
  timeoutMs: 8_000,
  allowedDataClasses: ["question", "course-passage"],
  capabilities: {
    languages: ["en"],
    modes: ["extractive", "generative"],
    modalities: ["text"],
    structuredOutput: true,
  },
};

describe("provider runtime configuration", () => {
  it.each(["openai", "gemini", "xai"])(
    "registers the native %s adapter without transmitting before consent",
    async (adapter) => {
      const binding = { ...remoteProvider, endpoint: undefined };
      const config = parseConfig({
        ...baseEnvironment,
       AI_PROVIDER: adapter,
       AI_LADDER: `${adapter},offline`,
       AI_PROVIDERS: JSON.stringify([
          { ...binding, id: adapter, adapter },
        ]),
        TEST_LLM_CREDENTIAL: "test-only-native-key",
      });
      const response = {
        text: "Choose one learning goal.",
        usedPassageIds: ["goals"],
      };
      const network = vi.fn<typeof fetch>(async (input, init) =>
        Response.json(
          (input instanceof Request ? input.method : init?.method) !== "POST"
            ? {}
            : adapter === "gemini"
              ? {
                  object: "interaction",
                  status: "completed",
                  model: "model-name",
                  steps: [
                    {
                      type: "model_output",
                      content: [
                        { type: "text", text: JSON.stringify(response) },
                      ],
                    },
                  ],
                }
              : {
                  status: "completed",
                  output: [
                    {
                      type: "message",
                      role: "assistant",
                      content: [
                        {
                          type: "output_text",
                          text: JSON.stringify(response),
                        },
                      ],
                    },
                  ],
                },
        ),
      );
      vi.stubGlobal("fetch", network);
      const runtime = createApiProviderRuntime(
        config,
        loadPacks(resolve("locales")),
        { TEST_LLM_CREDENTIAL: "test-only-native-key" },
      );
      const answerRequest = {
        question: "How do I choose a learning goal?",
        lang: "en",
        simple: false,
        mode: "extractive" as const,
        systemPrompt: "Use the supplied passages.",
        glossary: [],
        passages: [
          {
            id: "goals",
            text: "Choose one learning goal.",
            label: "Goals",
            url: "https://course.example/goals",
            lang: "en",
            sourceType: "course" as const,
          },
        ],
      };
      try {
        expect(
          (await runtime.answer(answerRequest, { cloudOk: false })).provider,
        ).toBe("offline");
        expect(network).not.toHaveBeenCalled();
        const remoteAnswer = await runtime.answer(answerRequest, {
          cloudOk: true,
        });
        expect(remoteAnswer.provider).toBe(adapter);
        expect(network).toHaveBeenCalledTimes(2);
        expect(JSON.stringify(runtime)).not.toContain("test-only-native-key");
      } finally {
        vi.unstubAllGlobals();
      }
    },
  );

  it("uses configured priorities for remaining enabled fallback bindings", () => {
    const config = parseConfig({
      ...baseEnvironment,
     AI_PROVIDER: "selected",
     AI_LADDER: "selected",
     AI_PROVIDERS: JSON.stringify([
        { ...remoteProvider, id: "later", priority: 30 },
        { ...remoteProvider, id: "selected", priority: 10 },
        { ...remoteProvider, id: "earlier", priority: 20 },
      ]),
      TEST_LLM_CREDENTIAL: "test-only-key",
    });
    const runtime = createApiProviderRuntime(
      config,
      loadPacks(resolve("locales")),
      { TEST_LLM_CREDENTIAL: "test-only-key" },
    );
    expect(runtime.providerOrder).toEqual([
      "selected",
      "earlier",
      "later",
      "offline",
    ]);
  });

  it("preserves an explicitly configured offline step before any later remote provider", () => {
    const config = parseConfig({
      ...baseEnvironment,
     AI_PROVIDER: "selected",
     AI_LADDER: "selected,offline,remote",
     AI_PROVIDERS: JSON.stringify([
        { ...remoteProvider, id: "selected" },
        { ...remoteProvider, id: "remote" },
      ]),
      TEST_LLM_CREDENTIAL: "test-only-key",
    });
    expect(
      createApiProviderRuntime(config, loadPacks(resolve("locales")), {
        TEST_LLM_CREDENTIAL: "test-only-key",
      }).providerOrder,
    ).toEqual(["selected", "offline", "remote"]);
  });

  it.each(["openai", "gemini", "xai"])(
    "requires native %s bindings to declare remote privacy and credentials",
    (adapter) => {
      expect(() =>
        parseConfig({
          ...baseEnvironment,
         AI_PROVIDERS: JSON.stringify([
            { ...remoteProvider, adapter, privacyClass: "local" },
          ]),
          TEST_LLM_CREDENTIAL: "test-only-key",
        }),
      ).toThrow(/privacyClass/u);
      const binding = { ...remoteProvider, credentialRef: undefined };
      expect(() =>
        parseConfig({
          ...baseEnvironment,
         AI_PROVIDERS: JSON.stringify([{ ...binding, adapter }]),
        }),
      ).toThrow(/credentialRef/u);
    },
  );
  it("parses arbitrary provider bindings without retaining credential values", () => {
    const config = parseConfig({
      ...baseEnvironment,
     AI_PROVIDER: "groq-fast",
     AI_LADDER: "groq-fast,offline",
     AI_PROVIDERS: JSON.stringify([remoteProvider]),
     AI_MAX_TOKENS: "256",
     AI_TEMPERATURE: "0.15",
      TEST_LLM_CREDENTIAL: "credential-value-not-for-config",
    });

    expect(config.AI_PROVIDER).toBe("groq-fast");
    expect(config.AI_PROVIDERS).toEqual([
      { ...remoteProvider, evaluatedLanguages: [] },
    ]);
    expect(config.AI_MAX_TOKENS).toBe(256);
    expect(config.AI_TEMPERATURE).toBe(0.15);
    expect(JSON.stringify(config)).not.toContain(
      "credential-value-not-for-config",
    );
  });

  it("defaults to offline answers and bounded deterministic generation settings", () => {
    const config = parseConfig(baseEnvironment);

    expect(config.AI_PROVIDER).toBe("offline");
    expect(config.AI_PROVIDERS).toEqual([]);
    expect(config.AI_MAX_TOKENS).toBe(400);
    expect(config.AI_TEMPERATURE).toBe(0.1);
  });

  it("uses a local model without cloud consent and falls back offline on failure", async () => {
    const config = parseConfig({
      ...baseEnvironment,
     AI_PROVIDER: "local-model",
     AI_LADDER: "local-model,offline",
     AI_PROVIDERS: JSON.stringify([
        {
          ...remoteProvider,
          id: "local-model",
          endpoint: "http://127.0.0.1:8080/v1",
          credentialRef: undefined,
          privacyClass: "local",
          allowedDataClasses: ["question", "course-passage", "glossary"],
          evaluatedLanguages: ["en"],
          capabilities: {
            languages: ["en"],
            modes: ["extractive"],
            modalities: ["text"],
            structuredOutput: true,
          },
        },
      ]),
    });
    const runtime = createApiProviderRuntime(
      config,
      loadPacks(resolve("locales")),
      {},
    );
    const answerRequest = {
      question: "How do I choose a learning goal?",
      lang: "en",
      simple: false,
      mode: "extractive" as const,
      systemPrompt: "Answer from supplied passages.",
      glossary: [],
      passages: [
        {
          id: "goals",
          text: "Choose one learning goal.",
          label: "Goals",
          url: "https://course.example/goals",
          lang: "en",
          sourceType: "course" as const,
        },
      ],
    };
    const fetchMock = vi.fn<typeof fetch>(async (input, init) => {
      const url = String(input);
      if (url.endsWith("/models")) {
        return Response.json({ data: [{ id: "local-model" }] });
      }
      if (init?.method !== "POST") {
        throw new Error("Unexpected local model request.");
      }
      return Response.json({
        choices: [
          {
            message: {
              content: JSON.stringify({
                text: "Choose one learning goal.",
                usedPassageIds: ["goals"],
              }),
            },
          },
        ],
      });
    });
    vi.stubGlobal("fetch", fetchMock);

    try {
      const localAnswer = await runtime.answer(answerRequest, {
        cloudOk: false,
      });
      expect(localAnswer.provider).toBe("local-model");
      expect(fetchMock).toHaveBeenCalledTimes(2);
      expect(fetchMock.mock.calls[0]?.[0]).toBe(
        "http://127.0.0.1:8080/v1/models",
      );
      expect(fetchMock.mock.calls[1]?.[0]).toBe(
        "http://127.0.0.1:8080/v1/chat/completions",
      );
      expect(fetchMock.mock.calls[1]?.[1]?.headers).not.toHaveProperty(
        "authorization",
      );

      fetchMock.mockImplementation(async (input) =>
        String(input).endsWith("/models")
          ? Response.json({ data: [{ id: "local-model" }] })
          : new Response("local model unavailable", { status: 503 }),
      );
      const fallbackAnswer = await runtime.answer(answerRequest, {
        cloudOk: false,
      });
      expect(fallbackAnswer.provider).toBe("offline");
      expect(fallbackAnswer.usedPassageIds).toContain("goals");
      expect(fallbackAnswer.text).toContain("Choose one learning goal.");
    } finally {
      vi.unstubAllGlobals();
    }
  });

  it("rejects malformed bindings, unresolved credentials, and unsafe limits", () => {
    expect(() =>
      parseConfig({
        ...baseEnvironment,
       AI_PROVIDERS: "{not-json",
      }),
    ).toThrow(/AI_PROVIDERS/u);

    expect(() =>
      parseConfig({
        ...baseEnvironment,
       AI_PROVIDERS: JSON.stringify([remoteProvider]),
      }),
    ).toThrow(/TEST_LLM_CREDENTIAL/u);

    expect(() =>
      parseConfig({
        ...baseEnvironment,
       AI_PROVIDERS: JSON.stringify([
          { ...remoteProvider, privacyClass: "unspecified" },
        ]),
        TEST_LLM_CREDENTIAL: "credential-value",
      }),
    ).toThrow(/privacyClass/u);

    expect(() =>
      parseConfig({
        ...baseEnvironment,
       AI_MAX_TOKENS: "0",
      }),
    ).toThrow(/AI_MAX_TOKENS/u);

    expect(() =>
      parseConfig({
        ...baseEnvironment,
       AI_TEMPERATURE: "2.5",
      }),
    ).toThrow(/AI_TEMPERATURE/u);
  });
});

describe("placeholder credentials", () => {
  it("recognises template values but never a real or short local token", async () => {
    const { isPlaceholderCredential } =
      await import("../src/provider-runtime.js");
    for (const value of [
      "REPLACE_WITH_YOUR_GEMINI_API_KEY",
      "your-api-key",
      "sk-or-...",
      "<gemini key>",
      "changeme",
    ])
      expect(isPlaceholderCredential(value)).toBe(true);
    for (const value of [
      "ollama",
      "AIzaSyD4x9y8Q7w6E5r4T3y2U1i0O9p8A7s6D5f",
      "sk-or-v1-0123456789abcdef0123456789abcdef",
    ])
      expect(isPlaceholderCredential(value)).toBe(false);
  });
});
