import { randomBytes } from "node:crypto";
import pg from "pg";
import type { AskDependencies } from "@bridgely/engine";
import type { JobsDelivery, JobsService } from "@bridgely/jobs";
import { JobsError } from "@bridgely/jobs";
import type { LangPack } from "@bridgely/locales-tools";
import { createSmsGateway, SmsError, SmsService } from "@bridgely/sms";
import type {
  SmsGateway,
  SmsGatewayFactoryOptions,
  SmsLocale,
  SmsServiceOptions,
} from "@bridgely/sms";
import type { ApiConfig } from "./config.js";
import type { ApiRepository } from "./types.js";
import { createConversationService } from "./conversation.js";
import { sha256 } from "./middleware/auth.js";

export type SmsApiService = Pick<SmsService, "inbound" | "sendAlert">;
export const SMS_CALLBACK_VERSION = "Bridgely.sms.callback.v1";

export function smsGatewayOptions(
  config: ApiConfig,
): SmsGatewayFactoryOptions | undefined {
  switch (config.SMS_MODE) {
    case "simulator":
      return { type: "simulator" };
    case "smsethiopia":
      if (!config.SMS_GATEWAY_TOKEN) return undefined;
      return {
        type: "smsethiopia",
        token: config.SMS_GATEWAY_TOKEN,
        ...(config.SMS_GATEWAY_URL
          ? { url: config.SMS_GATEWAY_URL }
          : {}),
      };
    case "gateway":
      if (!config.SMS_GATEWAY_URL || !config.SMS_GATEWAY_TOKEN)
        return undefined;
      return {
        type: "gateway",
        url: config.SMS_GATEWAY_URL,
        token: config.SMS_GATEWAY_TOKEN,
      };
  }
}

export function smsConfigured(config: ApiConfig): boolean {
  return Boolean(config.SMS_GATEWAY_SECRET && smsGatewayOptions(config));
}

export function createSmsCallback(
  config: ApiConfig,
  transport: typeof fetch = fetch,
): SmsServiceOptions["callback"] {
  if (!config.SMS_CALLBACK_URL || !config.SMS_CALLBACK_SECRET)
    return undefined;
  return async (input) => {
    try {
      const response = await transport(config.SMS_CALLBACK_URL!, {
        method: "POST",
        redirect: "error",
        signal: AbortSignal.timeout(5000),
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${config.SMS_CALLBACK_SECRET!}`,
          "Idempotency-Key": input.idempotencyKey,
        },
        body: JSON.stringify({ version: SMS_CALLBACK_VERSION, ...input }),
      });
      if (!response.ok) throw new Error("Callback rejected");
      const receipt: unknown = await response.json();
      if (
        !receipt ||
        typeof receipt !== "object" ||
        !("version" in receipt) ||
        receipt.version !== SMS_CALLBACK_VERSION ||
        !("accepted" in receipt) ||
        receipt.accepted !== true ||
        !("idempotencyKey" in receipt) ||
        receipt.idempotencyKey !== input.idempotencyKey
      )
        throw new Error("Invalid callback receipt");
    } catch {
      throw new SmsError("unavailable", input.lang);
    }
  };
}

/** Override only the native SMS digest port; keep all host accommodation and
 * other channel behavior intact. The thunk resolves the jobs/SMS dependency. */
export function withSmsJobsDelivery(
  host: JobsDelivery,
  service: () => SmsApiService | undefined,
  enabled: boolean,
): JobsDelivery {
  const otherChannels = host.channels.filter((channel) => channel !== "sms");
  return {
    channels: enabled ? [...otherChannels, "sms"] : otherChannels,
    relayAvailable: host.relayAvailable,
    async sendDigest(input) {
      if (input.channel !== "sms") return host.sendDigest(input);
      if (!enabled) throw new JobsError("unavailable");
      const sms = service();
      if (!sms) throw new JobsError("unavailable");
      try {
        await sms.sendAlert({
          contact: input.contact,
          text: input.text,
          lang: input.lang,
          idempotencyKey: input.idempotencyKey,
        });
      } catch {
        throw new JobsError("delivery_failed");
      }
    },
    sendAccommodation: (input) => host.sendAccommodation(input),
  };
}

function smsLocale(packs: Map<string, LangPack>, lang: string): SmsLocale {
  const source = (packs.get(lang)?.sms ?? packs.get("en")?.sms ?? {}) as Record<
    string,
    unknown
  >;
  return {
    strings: Object.fromEntries(
      Object.entries(source).filter(
        (entry): entry is [string, string] => typeof entry[1] === "string",
      ),
    ),
    keywords: (typeof source.keywords === "object" && source.keywords !== null
      ? source.keywords
      : {}) as Record<string, string[]>,
  };
}

export function createSmsRuntime(options: {
  config: ApiConfig;
  pool: pg.Pool;
  repository: ApiRepository;
  packs: Map<string, LangPack>;
  askDependencies?: AskDependencies;
  jobs?: Pick<JobsService, "subscribe"> &
    Partial<Pick<JobsService, "stopContact">>;
  gateway?: SmsGateway;
  callbackTransport?: typeof fetch;
}): { service: SmsService; close(): Promise<void> } | undefined {
  const { config, pool, repository, packs, jobs } = options;
  if (!smsConfigured(config)) return undefined;
  // SMS holds advisory locks across application calls; a separate bounded pool
  // prevents those locks from starving tutor/jobs or priority STOP revocation.
  const smsPool = new pg.Pool({
    connectionString: config.DATABASE_URL,
    max: 4,
    connectionTimeoutMillis: 15_000,
    idleTimeoutMillis: 30000,
  });
  smsPool.on("error", () => undefined);
  const gateway =
    options.gateway ??
    (() => {
      const gatewayOptions = smsGatewayOptions(config);
      return gatewayOptions ? createSmsGateway(gatewayOptions) : undefined;
    })();
  if (!gateway) return undefined;
  const conversation = createConversationService({
    config,
    repository,
    packs,
    ...(options.askDependencies
      ? { askDependencies: options.askDependencies }
      : {}),
  });
  const service = new SmsService({
    pool: smsPool,
    revocationPool: pool,
    hashKey: Buffer.from(config.HASH_KEY, "base64"),
    encryptionKey: Buffer.from(config.ENC_KEY, "base64"),
    gateway,
    dailyLimit: config.SMS_DAILY_LIMIT,
    locales: (lang) => smsLocale(packs, lang),
    sessions: {
      async create(lang) {
        const id = randomBytes(16).toString("base64url");
        await repository.createSession({
          id,
          lang,
          channel: "sms",
          cloudOk: false,
          consentVersion: null,
          tokenHash: sha256(randomBytes(32).toString("base64url")),
          resumeHash: sha256(randomBytes(32).toString("base64url")),
        });
        return id;
      },
      async setLanguage(id, lang) {
        await pool.query(
          "UPDATE session SET lang=$2,last_seen_at=now() WHERE id=$1 AND channel='sms'",
          [id, lang],
        );
      },
      async delete(id) {
        await repository.deleteSessionData(id);
      },
    },
    async ask(input) {
      await repository.touchSession(input.sessionId);
      const reply = await conversation({ ...input, via: "sms", simple: false });
      return [
        reply.text,
        ...reply.citations.map(
          (citation) => `${citation.label}: ${citation.url}`,
        ),
      ].join("\n");
    },
    ...(jobs?.stopContact
      ? {
          jobs: {
            subscribe: (input) => jobs.subscribe(input),
            stopContact: (contact) =>
              jobs.stopContact!({ channel: "sms", contact }),
          },
        }
      : {}),
    callback: createSmsCallback(config, options.callbackTransport),
  });
  gateway.onInbound(async (from, text, metadata) => {
    if (!metadata?.id) throw new SmsError("invalid");
    await service.inbound({ id: metadata.id, from, text });
  });
  return { service, close: () => smsPool.end() };
}
