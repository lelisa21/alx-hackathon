import type { LangPack } from "@bridgely/locales-tools";
import type { ApiConfig } from "./config.js";

export interface VoiceCapabilities {
  stt: boolean;
  tts: boolean;
  voice: { engine: "browser"; bcp_tag: string } | null;
}

/** Dialects may differ, but a voice must preserve the language and script. */
export function isMatchingVoiceLanguage(
  language: string,
  tag: string,
): boolean {
  try {
    const pack = new Intl.Locale(language).maximize();
    const voice = new Intl.Locale(tag).maximize();
    return pack.language === voice.language && pack.script === voice.script;
  } catch {
    return false;
  }
}

function isReviewed(pack: LangPack): boolean {
  const { status, reviewed_by: reviewer, reviewed_on: date } = pack.meta;
  if (
    (status !== "beta" && status !== "live") ||
    typeof reviewer !== "string" ||
    !reviewer.trim() ||
    /^(todo|tbd|unknown|none|pending)$/iu.test(reviewer.trim()) ||
    typeof date !== "string" ||
    !/^\d{4}-\d{2}-\d{2}$/u.test(date)
  )
    return false;
  const instant = Date.parse(`${date}T00:00:00Z`);
  return (
    Number.isFinite(instant) &&
    instant <= Date.now() &&
    new Date(instant).toISOString().slice(0, 10) === date
  );
}

const previewTags: Record<string, string> = {
  en: "en-US",
  am: "am-ET",
  om: "om-ET",
  ti: "ti-ET",
  so: "so-SO",
  sw: "sw-KE",
  ar: "ar-SA",
  fr: "fr-FR",
};

/** Pack flags record human approval of the device protocol, never a computed score. */
export function getVoiceCapabilities(
  pack: LangPack,
  config: Pick<ApiConfig, "STT_ENGINE" | "TTS_ENGINE"> &
    Partial<Pick<ApiConfig, "VOICE_PREVIEW">>,
): VoiceCapabilities {
  const unavailable: VoiceCapabilities = {
    stt: false,
    tts: false,
    voice: null,
  };
  if (config.VOICE_PREVIEW) {
    // Development preview (config rejects it elsewhere): skip the review gate
    // but keep engine selection and language/script matching. The widget still
    // feature-detects browser support at runtime.
    const configured = pack.voice.bcp_tag;
    const tag =
      typeof configured === "string" && configured
        ? configured
        : previewTags[pack.meta.code];
    if (!tag || !isMatchingVoiceLanguage(pack.meta.code, tag))
      return unavailable;
    const stt = config.STT_ENGINE === "browser";
    const tts = config.TTS_ENGINE === "browser";
    return {
      stt,
      tts,
      voice: stt || tts ? { engine: "browser", bcp_tag: tag } : null,
    };
  }
  const { engine, bcp_tag: tag } = pack.voice;
  if (
    !isReviewed(pack) ||
    engine !== "browser" ||
    typeof tag !== "string" ||
    tag.length < 2 ||
    tag.length > 35 ||
    !isMatchingVoiceLanguage(pack.meta.code, tag)
  )
    return unavailable;
  const stt = config.STT_ENGINE === "browser" && pack.meta.stt === true;
  const tts = config.TTS_ENGINE === "browser" && pack.meta.tts === true;
  return {
    stt,
    tts,
    voice: stt || tts ? { engine, bcp_tag: tag } : null,
  };
}
