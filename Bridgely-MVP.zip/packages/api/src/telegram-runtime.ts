import { randomBytes } from "node:crypto";
import pg from "pg";
import type { AskDependencies } from "@bridgely/engine";
import { JobsError } from "@bridgely/jobs";
import type { JobsDelivery } from "@bridgely/jobs";
import type { LangPack } from "@bridgely/locales-tools";
import {
  TelegramService,
  TelegramTransportError,
  createTelegramVoice,
  createTelegramTransport,
  startTelegramPolling,
} from "@bridgely/telegram";
import type {
  TelegramTransport,
  TelegramVoice,
  TelegramServiceOptions,
} from "@bridgely/telegram";
import type { ApiConfig } from "./config.js";
import type { ApiRepository, HelpStore } from "./types.js";
import type { HelpSocketRuntime, HelpSocketStore } from "./help-sockets.js";
import type { JobsApiService } from "./routes/jobs.js";
import { createConversationService } from "./conversation.js";
import { createTelegramHelpBridge } from "./telegram-help.js";
import { sha256 } from "./middleware/auth.js";
import { AskRequestSchema } from "./schemas.js";
import { createCareerRenderers } from "./jobs-format.js";

/** Keep channel callers on the same validated contract as the web ask route. */
export function createTelegramAsk(options: {
  conversation: ReturnType<typeof createConversationService>;
  repository: Pick<ApiRepository, "touchSession">;
}): TelegramServiceOptions["ask"] {
  return async (input) => {
    if (Array.from(input.text).length > 1000) throw new Error("too_long");
    const body = AskRequestSchema.parse({
      ...input,
      clientMsgId: sha256(input.clientMsgId),
      via: "telegram",
    });
    await options.repository.touchSession(body.sessionId);
    return options.conversation(body);
  };
}

export type TelegramApiService = Pick<
  TelegramService,
  "handleUpdate" | "sendAlert"
>;
export function telegramConfigured(config: ApiConfig) {
  return Boolean(config.TELEGRAM_TOKEN);
}

/** Content-free Telegram setup/polling failure for operators. */
export interface TelegramRuntimeError {
  stage: "commands" | "webhook" | "polling";
  /** Bot API error_code: 401 bad token, 409 another poller or webhook. */
  code?: number;
  failures?: number;
  retryMs?: number;
}

const errorCode = (error: unknown) =>
  error instanceof TelegramTransportError && error.code
    ? { code: error.code }
    : {};

/** Native Telegram is the sole digest path: legacy host delivery cannot bypass
 * consent checks, permanent Stop, deduplication or the per-chat send queue. */
export function withTelegramJobsDelivery(
  host: JobsDelivery,
  service: () => TelegramApiService | undefined,
  enabled: boolean,
): JobsDelivery {
  const channels = host.channels.filter((channel) => channel !== "telegram");
  return {
    channels: enabled ? [...channels, "telegram"] : channels,
    relayAvailable: host.relayAvailable,
    async sendDigest(input) {
      if (input.channel !== "telegram") return host.sendDigest(input);
      const telegram = service();
      if (!enabled || !telegram) throw new JobsError("unavailable");
      try {
        await telegram.sendAlert({
          contact: input.contact,
          lang: input.lang,
          text: input.text,
          idempotencyKey: input.idempotencyKey,
        });
      } catch {
        throw new JobsError("delivery_failed");
      }
    },
    sendAccommodation: (input) => host.sendAccommodation(input),
  };
}

function locale(
  packs: Map<string, LangPack>,
  lang: string,
): Record<string, string> {
  const source = { ...packs.get("en")?.ui, ...packs.get(lang)?.ui };
  return Object.fromEntries(
    Object.entries(source).filter(
      (entry): entry is [string, string] =>
        (entry[0].startsWith("telegram.") || entry[0] === "jobs.all") &&
        typeof entry[1] === "string",
    ),
  );
}

/** Telegram command menus accept ISO 639-1 language codes, while learner
 * language choices and shared sessions keep their full registry BCP 47 tags. */
export function telegramCommandRegistrations(packs: Map<string, LangPack>) {
  const commands = (lang: string) => {
    const strings = locale(packs, lang);
    return [
      "start",
      "language",
      "help",
      "jobs",
      "simple",
      "stop",
      "privacy",
      "endhelp",
    ].map((command) => ({
      command,
      description: strings[`telegram.command_${command}`]!,
    }));
  };
  const aliases = [...packs.values()]
    .filter(({ meta }) => meta.status !== "draft")
    .flatMap((pack) => {
      try {
        const tag = new Intl.Locale(pack.meta.code);
        return /^[a-z]{2}$/u.test(tag.language)
          ? [
              {
                code: pack.meta.code,
                canonical: tag.toString(),
                language: tag.language,
              },
            ]
          : [];
      } catch {
        return [];
      }
    })
    .sort(
      (a, b) =>
        a.language.localeCompare(b.language, "en") ||
        Number(b.canonical === b.language) -
          Number(a.canonical === a.language) ||
        a.canonical.localeCompare(b.canonical, "en"),
    );
  const selected = new Map<string, string>();
  for (const alias of aliases)
    if (!selected.has(alias.language)) selected.set(alias.language, alias.code);
  return [
    { languageCode: "", commands: commands("en") },
    ...[...selected].map(([languageCode, code]) => ({
      languageCode,
      commands: commands(code),
    })),
  ];
}

export function createTelegramRuntime(options: {
  config: ApiConfig;
  pool: pg.Pool;
  repository: ApiRepository;
  packs: Map<string, LangPack>;
  askDependencies?: AskDependencies;
  jobs?: JobsApiService;
  transport?: TelegramTransport;
  voice?: TelegramVoice;
  /** Cloud transcription for voice notes when no voice port is supplied. */
  cloudVoice?: Parameters<typeof createTelegramVoice>[0]["adapters"];
  helpStore?: HelpStore;
  helpSocketStore?: HelpSocketStore;
  socket(): HelpSocketRuntime | undefined;
  onError?(event: TelegramRuntimeError): void;
  /** Called once the webhook is registered with Telegram. */
  onWebhookRegistered?(url: string): void;
}) {
  const { config, pool, repository, packs } = options;
  if (!telegramConfigured(config)) return undefined;
  // Advisory locks cannot occupy the shared engine/help pool or starve STOP.
  const telegramPool = new pg.Pool({
    connectionString: config.DATABASE_URL,
    max: 4,
    connectionTimeoutMillis: 500,
    idleTimeoutMillis: 30000,
  });
  telegramPool.on("error", () => undefined);
  const transport =
    options.transport ??
    createTelegramTransport({
      token: config.TELEGRAM_TOKEN!,
      hashKey: config.HASH_KEY,
    });
  const conversation = createConversationService({
    config,
    repository,
    packs,
    ...(options.askDependencies
      ? { askDependencies: options.askDependencies }
      : {}),
  });
  const bridge: ReturnType<typeof createTelegramHelpBridge> | undefined =
    options.helpStore && options.helpSocketStore
      ? createTelegramHelpBridge({
          help: options.helpStore,
          store: options.helpSocketStore,
          socket: options.socket,
          send: (input): Promise<void> => service.sendHelper(input),
        })
      : undefined;
  const sessions: TelegramServiceOptions["sessions"] = {
    async ensure({ contactHash, lang }) {
      const result = await pool.query<{ id: string; lang: string }>(
        `INSERT INTO session(id,channel,lang,contact_hmac,token_hash,resume_hash,cloud_ok,consent_version)
         VALUES($1,'telegram',$2,$3,$4,$5,false,NULL)
         ON CONFLICT (channel,contact_hmac) WHERE contact_hmac IS NOT NULL
         DO UPDATE SET last_seen_at=now() RETURNING id,lang`,
        [
          randomBytes(16).toString("base64url"),
          lang,
          contactHash,
          sha256(randomBytes(32).toString("base64url")),
          sha256(randomBytes(32).toString("base64url")),
        ],
      );
      return result.rows[0]!;
    },
    async setLanguage(id, lang) {
      await pool.query(
        "UPDATE session SET lang=$2,last_seen_at=now() WHERE id=$1 AND channel='telegram'",
        [id, lang],
      );
    },
    async delete(id) {
      await repository.deleteSessionData(id);
    },
  };
  const service: TelegramService = new TelegramService({
    pool: telegramPool,
    revocationPool: pool,
    hashKey: Buffer.from(config.HASH_KEY, "base64"),
    encryptionKey: Buffer.from(config.ENC_KEY, "base64"),
    transport,
    locales: (lang) => locale(packs, lang),
    languages: [...packs.values()]
      .filter(({ meta }) => meta.status !== "draft")
      .map(({ meta }) => ({ code: meta.code, label: meta.name_native })),
    sessions,
    ask: createTelegramAsk({ conversation, repository }),
    renderJobs: createCareerRenderers(packs).renderDigest,
    ...(options.jobs?.stopContact
      ? {
          jobs: {
            listJobs: (input) => options.jobs!.listJobs(input),
            listSubscriptions: (input) =>
              options.jobs!.listSubscriptions(input),
            subscribe: (input) => options.jobs!.subscribe(input),
            stopContact: (input) => options.jobs!.stopContact!(input),
          },
        }
      : {}),
    ...(bridge
      ? {
          help: {
            start: bridge.start,
            relay: bridge.relay,
            end: bridge.end,
            bind: async (input) => {
              await bridge.bind(input);
            },
            async stopSession(sessionId: string) {
              const requests = await pool.query<{ id: string }>(
                "SELECT id FROM help_request WHERE session_id=$1 AND channel='telegram' AND status IN ('waiting','claimed')",
                [sessionId],
              );
              for (const request of requests.rows)
                await bridge.end({ sessionId, requestId: request.id });
            },
          },
        }
      : {}),
    ...(options.voice
      ? { voice: options.voice }
      : options.cloudVoice
        ? {
            voice: createTelegramVoice({
              transport,
              adapters: options.cloudVoice,
            }),
            // Audio goes to a remote speech service: ask each chat once.
            voiceConsentRequired: true,
          }
        : {}),
  });
  const ready = (async () => {
    for (const registration of telegramCommandRegistrations(packs)) {
      await transport.setCommands(
        registration.commands,
        registration.languageCode,
      );
    }
  })().catch((error: unknown) =>
    options.onError?.({ stage: "commands", ...errorCode(error) }),
  );
  // Webhook mode needs Telegram to know the public URL. With
  //PUBLIC_API_URL set, register it on every start so a redeploy or a
  // changed secret never leaves the bot silent.
  const webhookUrl =
    config.TELEGRAM_MODE === "webhook" &&
    config.PUBLIC_API_URL &&
    config.TELEGRAM_SECRET &&
    config.PUBLIC_API_URL.startsWith("https://")
      ? `${config.PUBLIC_API_URL}/v1/telegram/webhook`
      : undefined;
  const webhook =
    webhookUrl && transport.setWebhook
      ? transport
          .setWebhook({
            url: webhookUrl,
            secret: config.TELEGRAM_SECRET!,
          })
          .then(() => options.onWebhookRegistered?.(webhookUrl))
          .catch((error: unknown) =>
            options.onError?.({ stage: "webhook", ...errorCode(error) }),
          )
      : Promise.resolve();
  const polling =
    config.TELEGRAM_MODE === "polling"
      ? startTelegramPolling({
          transport,
          environment: config.NODE_ENV,
          handleUpdate: (update) => service.handleUpdate(update),
          onError: (event) => options.onError?.({ stage: "polling", ...event }),
        })
      : undefined;
  void polling?.done.catch(() => options.onError?.({ stage: "polling" }));
  return {
    service,
    ready: Promise.all([ready, webhook]).then(() => undefined),
    helpSocketStore: bridge?.store,
    forgetHelp: (requestId: string) => bridge?.forget(requestId),
    async close() {
      await polling?.stop();
      bridge?.clear();
      await transport.close();
      await telegramPool.end();
    },
  };
}
