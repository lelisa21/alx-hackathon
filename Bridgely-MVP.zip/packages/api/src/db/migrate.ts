import { readdir, readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import pg from "pg";

// Arbitrary constant; serialises migrators when deploy instances overlap.
const MIGRATION_LOCK_ID = 4_731_202_611;

export async function applyMigrations(
  client: pg.Client,
  directory: string,
): Promise<string[]> {
  await client.query("SELECT pg_advisory_lock($1)", [MIGRATION_LOCK_ID]);
  try {
    return await applyPendingMigrations(client, directory);
  } finally {
    await client.query("SELECT pg_advisory_unlock($1)", [MIGRATION_LOCK_ID]);
  }
}

async function applyPendingMigrations(
  client: pg.Client,
  directory: string,
): Promise<string[]> {
  await client.query(
    `CREATE TABLE IF NOT EXISTS _migrations (
       name TEXT PRIMARY KEY,
       applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
     )`,
  );
  const completed = await client.query<{ name: string }>(
    "SELECT name FROM _migrations",
  );
  const applied = new Set(completed.rows.map((row) => row.name));
  const pending = (await readdir(directory))
    .filter((file) => file.endsWith(".sql"))
    .sort();
  const newlyApplied: string[] = [];

  for (const file of pending) {
    if (applied.has(file)) continue;
    const sql = await readFile(path.join(directory, file), "utf8");
    await client.query("BEGIN");
    try {
      await client.query(sql);
      await client.query("INSERT INTO _migrations (name) VALUES ($1)", [file]);
      await client.query("COMMIT");
      newlyApplied.push(file);
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    }
  }

  return newlyApplied;
}

export function resolveDirectConnectionString(): string {
  let connectionString = process.env.DATABASE_URL_DIRECT?.trim();
  if (
    !connectionString ||
    connectionString.includes("replace-with-a-local-password")
  ) {
    connectionString = process.env.DATABASE_URL?.trim();
  }
  if (!connectionString) {
    throw new Error(
      "DATABASE_URL_DIRECT or DATABASE_URL is required to run migrations",
    );
  }
  // If connecting to a Neon pooled host, direct connection is needed for advisory locks & DDL
  return connectionString.replace("-pooler.", ".");
}

async function main(): Promise<void> {
  const connectionString = resolveDirectConnectionString();
  const client = new pg.Client({ connectionString });
  await client.connect();
  try {
    const directory = path.resolve(
      path.dirname(fileURLToPath(import.meta.url)),
      "../../migrations",
    );
    const applied = await applyMigrations(client, directory);
    for (const migration of applied)
      process.stdout.write(`applied ${migration}\n`);
    if (applied.length === 0) process.stdout.write("No pending migrations.\n");
  } finally {
    await client.end();
  }
}

if (fileURLToPath(import.meta.url) === path.resolve(process.argv[1] ?? "")) {
  await main();
}
