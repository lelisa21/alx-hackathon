import { z } from "zod";
import type { ProviderBinding } from "@bridgely/ai";

const publicSourceSchema = z
  .object({
    id: z.string().regex(/^[A-Za-z0-9._-]{1,64}$/u),
    sitemapUrl: z
      .string()
      .url()
      .refine(
        (value) => value.toLowerCase().startsWith("https://"),
        "must use HTTPS",
      ),
    language: z.string().min(1).max(64),
    pageSize: z.number().int().min(1).max(100).optional(),
  })
  .strict();

type PublicSourceConfig = z.infer<typeof publicSourceSchema>;

const publicSourcesSchema = z
  .string()
  .default("[]")
  .transform((value, context): PublicSourceConfig[] | typeof z.NEVER => {
    let decoded: unknown;
    try {
      decoded = JSON.parse(value);
    } catch {
      context.addIssue({
        code: z.ZodIssueCode.custom,
        message: "must contain valid JSON",
      });
      return z.NEVER;
    }

    const parsed = z.array(publicSourceSchema).safeParse(decoded);
    if (!parsed.success) {
      const details = parsed.error.issues
        .map((issue) => {
          const path = issue.path.length > 0 ? `${issue.path.join(".")}: ` : "";
          return `${path}${issue.message}`;
        })
        .join("; ");
      context.addIssue({
        code: z.ZodIssueCode.custom,
        message: details,
      });
      return z.NEVER;
    }

    const ids = new Set<string>();
    for (const [index, source] of parsed.data.entries()) {
      if (ids.has(source.id)) {
        context.addIssue({
          code: z.ZodIssueCode.custom,
          message: `source ID at index ${index} must be unique`,
        });
        return z.NEVER;
      }
      ids.add(source.id);
    }
    return parsed.data;
  });

// Plain HTTP is accepted only for a local demo platform on this machine, and
// only with NODE_ENV=development (enforced in the superRefine below).
const LOCAL_HTTP_HOSTS = new Set([
  "localhost",
  "127.0.0.1",
  "host.docker.internal",
]);
export function isLocalHttpUrl(value: string): boolean {
  try {
    const url = new URL(value);
    return url.protocol === "http:" && LOCAL_HTTP_HOSTS.has(url.hostname);
  } catch {
    return false;
  }
}

const ltiPlatformUrlSchema = z
  .string()
  .url()
  .refine((value) => {
    const url = new URL(value);
    return (
      (url.protocol === "https:" || isLocalHttpUrl(value)) &&
      !url.username &&
      !url.password &&
      !url.search &&
      !url.hash
    );
  }, "must use HTTPS without credentials, query or fragment");

const ltiPlatformSchema = z
  .object({
    platformId: z.string().regex(/^[A-Za-z0-9._-]{1,64}$/u),
    issuer: ltiPlatformUrlSchema,
    clientId: z.string().min(1).max(256),
    authLoginUrl: ltiPlatformUrlSchema,
    authTokenUrl: ltiPlatformUrlSchema,
    jwksUri: ltiPlatformUrlSchema,
    deploymentId: z.string().min(1).max(256),
  })
  .strict();

const ltiPlatformsSchema = z
  .string()
  .default("[]")
  .transform((value, context) => {
    let decoded: unknown;
    try {
      decoded = JSON.parse(value);
    } catch {
      context.addIssue({
        code: z.ZodIssueCode.custom,
        message: "must contain valid JSON",
      });
      return z.NEVER;
    }

    const parsed = z.array(ltiPlatformSchema).safeParse(decoded);
    if (!parsed.success) {
      context.addIssue({
        code: z.ZodIssueCode.custom,
        message: parsed.error.issues
          .map((issue) => {
            const key =
              issue.path.length > 0 ? `${issue.path.join(".")}: ` : "";
            return `${key}${issue.message}`;
          })
          .join("; "),
      });
      return z.NEVER;
    }

    const platformIds = new Set<string>();
    const issuerClientPairs = new Set<string>();
    for (const [index, platform] of parsed.data.entries()) {
      const issuerClientPair = `${platform.issuer}\u0000${platform.clientId}`;
      if (
        platformIds.has(platform.platformId) ||
        issuerClientPairs.has(issuerClientPair)
      ) {
        context.addIssue({
          code: z.ZodIssueCode.custom,
          message: `platform ID and issuer/client pair at index ${index} must be unique`,
        });
        return z.NEVER;
      }
      platformIds.add(platform.platformId);
      issuerClientPairs.add(issuerClientPair);
    }

    return parsed.data;
  });

const providerCapabilitiesSchema = z
  .object({
    languages: z.array(z.string().min(1)).min(1),
    modes: z.array(z.enum(["extractive", "generative"])).min(1),
    modalities: z.array(z.enum(["text", "image", "audio"])).min(1),
    structuredOutput: z.boolean(),
  })
  .strict();

const providerBindingSchema = z
  .object({
    id: z.string().regex(/^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/u),
    adapter: z.string().regex(/^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/u),
    model: z.string().min(1).max(256),
    endpoint: z.string().url().optional(),
    credentialRef: z
      .string()
      .regex(/^[A-Z_][A-Z0-9_]*$/u)
      .optional(),
    privacyClass: z.enum(["local", "remote"]),
    enabled: z.boolean(),
    priority: z.number().int().min(0).max(100_000),
    timeoutMs: z.number().int().min(100).max(120_000),
    allowedDataClasses: z
      .array(z.enum(["question", "course-passage", "job-posting", "glossary"]))
      .refine((values) => new Set(values).size === values.length),
    evaluatedLanguages: z.array(z.string().min(1)).default([]),
    // OpenRouter only: models tried in order when the primary is rate
    // limited or down (OpenRouter allows three models per request).
    fallbackModels: z.array(z.string().min(1).max(256)).max(2).optional(),
    capabilities: providerCapabilitiesSchema,
  })
  .strict()
  .superRefine((binding, context) => {
    if (binding.fallbackModels?.length && binding.adapter !== "openrouter")
      context.addIssue({
        code: z.ZodIssueCode.custom,
        message: "fallbackModels is supported only by the openrouter adapter",
        path: ["fallbackModels"],
      });
    if (["openai", "gemini", "xai", "openrouter"].includes(binding.adapter)) {
      if (binding.privacyClass !== "remote")
        context.addIssue({
          code: z.ZodIssueCode.custom,
          message: "native vendor adapters require remote privacy",
          path: ["privacyClass"],
        });
      if (binding.enabled && !binding.credentialRef)
        context.addIssue({
          code: z.ZodIssueCode.custom,
          message: "native vendor adapters require a credential reference",
          path: ["credentialRef"],
        });
    }
    if (binding.privacyClass === "remote" && binding.endpoint) {
      if (new URL(binding.endpoint).protocol !== "https:") {
        context.addIssue({
          code: z.ZodIssueCode.custom,
          message: "remote provider endpoints must use HTTPS",
          path: ["endpoint"],
        });
      }
    }
  });

const providerBindingsSchema = z
  .string()
  .default("[]")
  .transform((value, context): ProviderBinding[] | typeof z.NEVER => {
    let decoded: unknown;
    try {
      decoded = JSON.parse(value);
    } catch {
      context.addIssue({
        code: z.ZodIssueCode.custom,
        message: "must contain valid JSON",
      });
      return z.NEVER;
    }
    const parsed = z.array(providerBindingSchema).safeParse(decoded);
    if (!parsed.success) {
      const details = parsed.error.issues
        .map((issue) => {
          const path = issue.path.length > 0 ? `${issue.path.join(".")}: ` : "";
          return `${path}${issue.message}`;
        })
        .join("; ");
      context.addIssue({
        code: z.ZodIssueCode.custom,
        message: details,
      });
      return z.NEVER;
    }
    return parsed.data;
  });

const helperHoursIntervalSchema = z
  .object({
    day: z.number().int().min(1).max(7),
    start: z.string().regex(/^(?:[01]\d|2[0-3]):[0-5]\d$/u),
    end: z.string().regex(/^(?:[01]\d|2[0-3]):[0-5]\d$/u),
  })
  .strict()
  .refine((interval) => interval.start < interval.end, {
    message: "interval start must be before end",
  });

const helperHoursSchema = z
  .string()
  .optional()
  .transform((value, context) => {
    if (value === undefined || value === "") return undefined;
    let decoded: unknown;
    try {
      decoded = JSON.parse(value);
    } catch {
      context.addIssue({
        code: z.ZodIssueCode.custom,
        message: "must contain valid JSON",
      });
      return z.NEVER;
    }

    const parsed = z.array(helperHoursIntervalSchema).safeParse(decoded);
    if (!parsed.success) {
      context.addIssue({
        code: z.ZodIssueCode.custom,
        message: parsed.error.issues
          .map((issue) => {
            const key =
              issue.path.length > 0 ? `${issue.path.join(".")}: ` : "";
            return `${key}${issue.message}`;
          })
          .join("; "),
      });
      return z.NEVER;
    }

    const intervalsByDay = new Map<
      number,
      Array<{ start: string; end: string }>
    >();
    for (const interval of parsed.data) {
      const intervals = intervalsByDay.get(interval.day) ?? [];
      if (
        intervals.some(
          ({ start, end }) => interval.start < end && interval.end > start,
        )
      ) {
        context.addIssue({
          code: z.ZodIssueCode.custom,
          message: `intervals overlap on ISO weekday ${interval.day}`,
        });
        return z.NEVER;
      }
      intervals.push(interval);
      intervalsByDay.set(interval.day, intervals);
    }
    return parsed.data;
  });

const base64Key = (length: number) =>
  z
    .string()
    .regex(/^[A-Za-z0-9+/]+={0,2}$/u)
    .refine((value) => {
      const decoded = Buffer.from(value, "base64");
      return (
        decoded.byteLength === length && decoded.toString("base64") === value
      );
    }, `must be ${length} random bytes in base64`);

const optionalSmsSecret = z.preprocess(
  (value) => (value === "" ? undefined : value),
  z.string().min(24).regex(/^\S+$/u).optional(),
);
const optionalSmsUrl = z.preprocess(
  (value) => (value === "" ? undefined : value),
  z
    .string()
    .url()
    .refine((value) => {
      const url = new URL(value);
      return (
        url.protocol === "https:" &&
        !url.username &&
        !url.password &&
        !url.search &&
        !url.hash
      );
    }, "must use HTTPS without credentials, query or fragment")
    .optional(),
);

const environmentSchema = z
  .object({
    NODE_ENV: z
      .enum(["development", "test", "production"])
      .default("development"),
    PORT: z.coerce.number().int().min(1).max(65535).default(3000),
    DATABASE_URL: z.string().min(1),
    DATABASE_URL_DIRECT: z.string().optional(),
   PUBLIC_SOURCES: publicSourcesSchema,
   LTI_PLATFORMS: ltiPlatformsSchema,
    // LTI launch page: the widget module URL and its public host key.
   LTI_WIDGET_URL: z.preprocess(
      (value) => (value === "" ? undefined : value),
      z
        .string()
        .url()
        .refine(
          (value) =>
            new URL(value).protocol === "https:" || isLocalHttpUrl(value),
          "must use HTTPS",
        )
        .optional(),
    ),
   LTI_WIDGET_KEY: z.preprocess(
      (value) => (value === "" ? undefined : value),
      z.string().min(1).max(256).optional(),
    ),
   SOURCE_SYNC_INTERVAL_MS: z.coerce
      .number()
      .int()
      .min(1_000)
      .max(86_400_000)
      .default(300_000),
   ENC_KEY: base64Key(32),
   HASH_KEY: base64Key(32),
   JWT_SECRET: z.string().min(32),
   CRON_SECRET: z.string().min(24),
   JOBS_RELAY_URL: z.preprocess(
      (value) => (value === "" ? undefined : value),
      z
        .string()
        .url()
        .refine((value) => {
          const url = new URL(value);
          return (
            url.protocol === "https:" &&
            !url.username &&
            !url.password &&
            !url.search &&
            !url.hash
          );
        }, "must use HTTPS without credentials, query or fragment")
        .optional(),
    ),
   JOBS_RELAY_SECRET: z.preprocess(
      (value) => (value === "" ? undefined : value),
      z.string().min(24).optional(),
    ),
    // Cloud speech for languages the browser cannot recognise or speak. Runs
    // only after the learner allows cloud voice for the session.
   CLOUD_VOICE: z.enum(["off", "gemini"]).default("off"),
    // Languages cloud speech recognition serves.
   CLOUD_VOICE_LANGS: z
      .string()
      .default("en,am,om,ti")
      .transform((value) =>
        value
          .split(",")
          .map((code) => code.trim())
          .filter(Boolean),
      ),
    // Languages cloud read-aloud serves. Gemini TTS speaks Amharic and
    // Tigrinya but not Afaan Oromoo
    // (https://aistudio.google.com/docs/speech-generation).
   CLOUD_VOICE_SPEAK_LANGS: z
      .string()
      .default("en,am,ti")
      .transform((value) =>
        value
          .split(",")
          .map((code) => code.trim())
          .filter(Boolean),
      ),
    // Comma-separated current Gemini audio-input models, tried in order.
   CLOUD_VOICE_STT_MODEL: z
      .string()
      .min(1)
      .default("gemini-3.6-flash,gemini-3.5-flash-lite,gemini-3.1-flash-lite"),
   CLOUD_VOICE_TTS_MODEL: z
      .string()
      .min(1)
      .default("gemini-3.8-flash-lite-tts,gemini-3.8-flash-tts"),
   CLOUD_VOICE_CREDENTIAL_REF: z
      .string()
      .min(1)
      .default("GEMINI_API_KEY"),
    // Job platforms to import from: ethiojobs, hahujobs, afriwork.
   JOB_SOURCES: z
      .string()
      .default("")
      .transform((value) =>
        value
          .split(",")
          .map((item) => item.trim().toLowerCase())
          .filter(Boolean),
      )
      .pipe(z.array(z.enum(["ethiojobs", "hahujobs", "afriwork"]))),
   JOB_SYNC_INTERVAL_MS: z.coerce
      .number()
      .int()
      .min(0)
      .max(604800000)
      .default(21600000),
   JOB_SYNC_LIMIT: z.coerce.number().int().min(1).max(200).default(40),
   JOB_USER_AGENT: z.string().max(200).default("BridgelyJobsBot/0.1"),
    // Partner feeds: HahuJobs and Afriwork publish no public API or feed.
   HAHUJOBS_FEED_URL: z.preprocess(
      (value) => (value === "" ? undefined : value),
      z.string().url().optional(),
    ),
   HAHUJOBS_FEED_TOKEN: z.preprocess(
      (value) => (value === "" ? undefined : value),
      z.string().min(8).max(512).optional(),
    ),
   AFRIWORK_FEED_URL: z.preprocess(
      (value) => (value === "" ? undefined : value),
      z.string().url().optional(),
    ),
   AFRIWORK_FEED_TOKEN: z.preprocess(
      (value) => (value === "" ? undefined : value),
      z.string().min(8).max(512).optional(),
    ),
   JOBS_ALERT_INTERVAL_MS: z.coerce
      .number()
      .int()
      .min(0)
      .max(86400000)
      .default(0)
      .refine(
        (value) => value === 0 || value >= 60000,
        "must be zero or at least 60000",
      ),
   JOBS_RELAY_CHANNELS: z
      .string()
      .default("")
      .transform((value, context) => {
        const channels = value
          .split(",")
          .map((item) => item.trim())
          .filter(Boolean);
        if (
          channels.some(
            (channel) => channel !== "sms" && channel !== "telegram",
          ) ||
          new Set(channels).size !== channels.length
        ) {
          context.addIssue({
            code: z.ZodIssueCode.custom,
            message: "must contain unique sms and/or telegram channels",
          });
          return z.NEVER;
        }
        return channels as Array<"sms" | "telegram">;
      }),
   HOST_ORIGINS: z.string().default(""),
    // Public HTTPS base URL of this API (no /v1), e.g.
    // https://Bridgely-api.onrender.com. In Telegram webhook mode the API
    // registers <url>/v1/telegram/webhook with Telegram on start.
   PUBLIC_API_URL: z.preprocess(
      (value) => (value === "" ? undefined : value),
      z
        .string()
        .url()
        .refine((value) => {
          const url = new URL(value);
          return (
            (url.protocol === "https:" || isLocalHttpUrl(value)) &&
            !url.username &&
            !url.password &&
            !url.search &&
            !url.hash
          );
        }, "must use HTTPS without credentials, query or fragment")
        .transform((value) => value.replace(/\/+$/u, "").replace(/\/v1$/u, ""))
        .optional(),
    ),
   DEFAULT_LANG: z.string().min(2).default("en"),
    // Draft packs this host publishes as beta. Review-gated features stay off.
   PREVIEW_LANGS: z
      .string()
      .default("")
      .transform((value) =>
        value
          .split(",")
          .map((code) => code.trim())
          .filter(Boolean),
      )
      .pipe(
        z.array(
          z
            .string()
            .regex(
              /^[a-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$/u,
              "invalid language code",
            ),
        ),
      ),
   STT_ENGINE: z.enum(["none", "browser"]).default("none"),
   TTS_ENGINE: z.enum(["none", "browser"]).default("none"),
    // Development only: try browser voice before the device review protocol.
   VOICE_PREVIEW: z
      .enum(["true", "false", ""])
      .default("false")
      .transform((value) => value === "true"),
   LANGUAGE_DETECTION_CONFIDENCE: z.coerce
      .number()
      .min(0)
      .max(1)
      .default(0.25),
   AI_PROVIDER: z.string().min(1).default("offline"),
   AI_LADDER: z.string().default("cloud,local,offline"),
   AI_PROVIDERS: providerBindingsSchema,
   AI_MAX_TOKENS: z.coerce.number().int().min(16).max(8192).default(400),
   AI_TEMPERATURE: z.coerce.number().min(0).max(2).default(0.1),
   AI_CONSENT_VERSION: z.string().min(1).max(64).default("remote-ai-v1"),
   CONFIDENCE_FLOOR: z.coerce.number().min(0).max(1).default(0.35),
    // Retrieval floor when a consented AI provider judges passage relevance.
   AI_RECALL_FLOOR: z.coerce.number().min(0).max(1).default(0.2),
   RETENTION_HOURS: z.coerce.number().int().positive().default(24),
   TELEGRAM_TOKEN: z.preprocess(
      (value) => (value === "" ? undefined : value),
      z
        .string()
        .max(256)
        .regex(/^\d{1,20}:[A-Za-z0-9_-]{20,}$/u)
        .optional(),
    ),
   TELEGRAM_SECRET: z.preprocess(
      (value) => (value === "" ? undefined : value),
      z
        .string()
        .min(24)
        .max(256)
        .regex(/^[A-Za-z0-9_-]+$/u)
        .optional(),
    ),
    // Unset or empty: polling in development, webhook otherwise (see
    // telegramMode). Production always rejects polling.
   TELEGRAM_MODE: z.preprocess(
      (value) => (value === "" ? undefined : value),
      z.enum(["webhook", "polling"]).optional(),
    ),
   SMS_MODE: z
      .enum(["simulator", "gateway", "smsethiopia"])
      .default("simulator"),
   SMS_GATEWAY_SECRET: optionalSmsSecret,
   SMS_GATEWAY_URL: optionalSmsUrl,
   SMS_GATEWAY_TOKEN: optionalSmsSecret,
   SMS_CALLBACK_URL: optionalSmsUrl,
   SMS_CALLBACK_SECRET: optionalSmsSecret,
   SMS_DAILY_LIMIT: z.coerce.number().int().min(1).max(1000).default(20),
   TURN_API_KEY: z.string().optional(),
   TURN_APP: z.preprocess(
      (value) => (value === "" ? undefined : value),
      z
        .string()
        .regex(/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/u)
        .optional(),
    ),
   HELPER_HOURS: helperHoursSchema,
   HELP_WAIT_TIMEOUT_MS: z.coerce
      .number()
      .int()
      .min(1000)
      .max(3600000)
      .default(300000),
   DB_BUDGET_MB: z.coerce.number().positive().default(600),
  })
  .superRefine((config, context) => {
    if (
      Boolean(config.LTI_WIDGET_URL) !==
      Boolean(config.LTI_WIDGET_KEY)
    )
      context.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["LTI_WIDGET_URL"],
        message:
          "LTI_WIDGET_URL andLTI_WIDGET_KEY must be configured together",
      });
    if (config.NODE_ENV !== "development") {
      const localHttp = [
        config.LTI_WIDGET_URL ?? "",
        ...config.LTI_PLATFORMS.flatMap((platform) => [
          platform.issuer,
          platform.authLoginUrl,
          platform.authTokenUrl,
          platform.jwksUri,
        ]),
      ].some(isLocalHttpUrl);
      if (localHttp)
        context.addIssue({
          code: z.ZodIssueCode.custom,
          path: ["LTI_PLATFORMS"],
          message:
            "Plain-HTTP LTI URLs are allowed only with NODE_ENV=development",
        });
    }
    if (config.VOICE_PREVIEW && config.NODE_ENV !== "development")
      context.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["VOICE_PREVIEW"],
        message:
          "Unreviewed voice preview is allowed only with NODE_ENV=development",
      });
    if (telegramMode(config) === "polling" && config.NODE_ENV === "production")
      context.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["TELEGRAM_MODE"],
        message:
          "Telegram polling is allowed only locally; production requires webhook mode",
      });
    if (
      config.TELEGRAM_TOKEN &&
      telegramMode(config) === "webhook" &&
      !config.TELEGRAM_SECRET
    )
      context.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["TELEGRAM_SECRET"],
        message: "Enabled Telegram webhooks require a separate secret",
      });
    if (
      config.TELEGRAM_SECRET &&
      [
        config.ENC_KEY,
        config.HASH_KEY,
        config.JWT_SECRET,
        config.CRON_SECRET,
        config.SMS_GATEWAY_SECRET,
        config.SMS_GATEWAY_TOKEN,
        config.SMS_CALLBACK_SECRET,
        config.JOBS_RELAY_SECRET,
      ].includes(config.TELEGRAM_SECRET)
    )
      context.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["TELEGRAM_SECRET"],
        message:
          "Telegram webhook secret must differ from other configured credentials",
      });
    if (
      config.SMS_MODE === "smsethiopia" &&
      !config.SMS_GATEWAY_TOKEN
    )
      context.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["SMS_GATEWAY_TOKEN"],
        message: "SMS Ethiopia mode requires the campaign API key",
      });
    if (
      config.SMS_MODE !== "smsethiopia" &&
      (Boolean(config.SMS_GATEWAY_URL) !==
        Boolean(config.SMS_GATEWAY_TOKEN) ||
        (config.SMS_MODE === "gateway" && !config.SMS_GATEWAY_URL))
    )
      context.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["SMS_GATEWAY_URL"],
        message:
          "SMS gateway URL and token must be configured together; gateway mode requires both",
      });
    if (
      Boolean(config.SMS_CALLBACK_URL) !==
      Boolean(config.SMS_CALLBACK_SECRET)
    )
      context.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["SMS_CALLBACK_URL"],
        message: "SMS callback URL and secret must be configured together",
      });
    if (
      config.SMS_GATEWAY_SECRET &&
      [
        config.ENC_KEY,
        config.HASH_KEY,
        config.JWT_SECRET,
        config.CRON_SECRET,
        config.JOBS_RELAY_SECRET,
        config.SMS_GATEWAY_TOKEN,
        config.SMS_CALLBACK_SECRET,
        config.TELEGRAM_SECRET,
      ].includes(config.SMS_GATEWAY_SECRET)
    )
      context.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["SMS_GATEWAY_SECRET"],
        message:
          "SMS inbound secret must differ from other configured credentials",
      });
    if (
      Boolean(config.JOBS_RELAY_URL) !==
        Boolean(config.JOBS_RELAY_SECRET) ||
      (config.JOBS_RELAY_CHANNELS.length > 0 &&
        !config.JOBS_RELAY_URL)
    ) {
      context.addIssue({
        code: z.ZodIssueCode.custom,
        message:
          "Job relay URL and secret must be configured together; relay channels require both",
      });
    }
    if (Boolean(config.TURN_API_KEY) !== Boolean(config.TURN_APP)) {
      context.addIssue({
        code: z.ZodIssueCode.custom,
        message:
          "TURN_API_KEY andTURN_APP must be configured together",
      });
    }
    const secrets = [
      config.ENC_KEY,
      config.HASH_KEY,
      config.JWT_SECRET,
    ];
    if (new Set(secrets).size !== secrets.length) {
      context.addIssue({
        code: z.ZodIssueCode.custom,
        message:
          "ENC_KEY,HASH_KEY, andJWT_SECRET must be different",
      });
    }
    const ids = new Set<string>();
    const bindings = Array.isArray(config.AI_PROVIDERS)
      ? config.AI_PROVIDERS
      : [];
    for (const [index, binding] of bindings.entries()) {
      if (binding.id === "offline" || ids.has(binding.id)) {
        context.addIssue({
          code: z.ZodIssueCode.custom,
          message: `AI_PROVIDERS[${index}].id must be unique and cannot be "offline"`,
        });
      }
      ids.add(binding.id);
    }
  });

type ParsedConfig = z.infer<typeof environmentSchema>;
export type ApiConfig = Omit<ParsedConfig, "TELEGRAM_MODE"> & {
 TELEGRAM_MODE: "webhook" | "polling";
};

function telegramMode(config: {
  NODE_ENV: string;
 TELEGRAM_MODE?: "webhook" | "polling" | undefined;
}): "webhook" | "polling" {
  return (
    config.TELEGRAM_MODE ??
    (config.NODE_ENV === "development" ? "polling" : "webhook")
  );
}

export function parseConfig(
  environment: NodeJS.ProcessEnv | Record<string, unknown>,
): ApiConfig {
  const parsed = environmentSchema.safeParse(environment);
  if (!parsed.success) {
    const details = parsed.error.issues
      .map((issue) => {
        const key = issue.path.length > 0 ? `${issue.path.join(".")}: ` : "";
        return `${key}${issue.message}`;
      })
      .join("; ");
    throw new Error(`Invalid API configuration: ${details}`);
  }
  const values = environment as Record<string, unknown>;
  for (const binding of parsed.data.AI_PROVIDERS) {
    if (
      binding.enabled &&
      binding.credentialRef &&
      (typeof values[binding.credentialRef] !== "string" ||
        !String(values[binding.credentialRef]).trim())
    ) {
      throw new Error(
        `Invalid API configuration: credential reference ${binding.credentialRef} is not set`,
      );
    }
  }
  if (
    parsed.data.AI_PROVIDER !== "offline" &&
    !parsed.data.AI_PROVIDERS.some(
      ({ id, enabled }) => id === parsed.data.AI_PROVIDER && enabled,
    )
  ) {
    throw new Error(
      `Invalid API configuration:AI_PROVIDER ${parsed.data.AI_PROVIDER} is not an enabled provider`,
    );
  }
  return {
    ...parsed.data,
   TELEGRAM_MODE: telegramMode(parsed.data),
  } as ApiConfig;
}

export function configuredOrigins(config: ApiConfig): string[] {
  return config.HOST_ORIGINS.split(",")
    .map((origin) => origin.trim())
    .filter(Boolean);
}
