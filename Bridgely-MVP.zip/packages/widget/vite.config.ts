import { defineConfig } from "vite";
import { loadPacks } from "../locales-tools/src/index.js";
import { fileURLToPath } from "node:url";
import { gzipSync } from "node:zlib";
import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { smsPagePlugin } from "./sms-page-plugin.js";

const htmlAttribute = (value: string) =>
  value
    .replaceAll("&", "&amp;")
    .replaceAll('"', "&quot;")
    .replaceAll("<", "&lt;");

export default defineConfig({
  server: {
    port: 5173,
    proxy: {
      "/v1": {
        target: "http://localhost:3000",
        changeOrigin: true,
      },
      "/sim": {
        target: "http://localhost:3000",
        changeOrigin: true,
      },
    },
  },
  plugins: [
    smsPagePlugin(),
    {
      name: "dimts-public-homepage",
      generateBundle() {
        const template = readFileSync(
          new URL("./public/templates/index.html.template", import.meta.url),
          "utf8",
        );
        const packs = loadPacks(
          fileURLToPath(new URL("../../locales", import.meta.url)),
        );
        const homeCopy = JSON.stringify(
          Object.fromEntries(
            [...packs].map(([code, pack]) => [
              code,
              {
                nativeName: pack.meta.name_native,
                ui: Object.fromEntries(
                  Object.entries(pack.ui).filter(([key]) =>
                    key.startsWith("home.access."),
                  ),
                ),
              },
            ]),
          ),
        ).replaceAll("<", "\\u003c");
        this.emitFile({
          type: "asset",
          fileName: "dimts-home-access.json",
          source: homeCopy,
        });
        const html = template
          .replaceAll(
            "${DIMTS_PUBLIC_API}",
            htmlAttribute(process.env.DIMTS_PUBLIC_API || process.env.PUBLIC_API || "/v1"),
          )
          .replaceAll(
            "${PUBLIC_API}",
            htmlAttribute(process.env.PUBLIC_API || process.env.DIMTS_PUBLIC_API || "/v1"),
          )
          .replaceAll(
            "${DIMTS_LOCAL_WIDGET_KEY}",
            htmlAttribute(
              process.env.DIMTS_PUBLIC_WIDGET_KEY ||
                process.env.DIMTS_LOCAL_WIDGET_KEY ||
                process.env.LOCAL_WIDGET_KEY ||
                "",
            ),
          )
          .replaceAll(
            "${LOCAL_WIDGET_KEY}",
            htmlAttribute(
              process.env.LOCAL_WIDGET_KEY ||
                process.env.DIMTS_PUBLIC_WIDGET_KEY ||
                process.env.DIMTS_LOCAL_WIDGET_KEY ||
                "",
            ),
          )
          .replaceAll(
            "${DIMTS_PUBLIC_TELEGRAM_BOT}",
            htmlAttribute(process.env.DIMTS_PUBLIC_TELEGRAM_BOT || process.env.PUBLIC_TELEGRAM_BOT || ""),
          )
          .replaceAll(
            "${PUBLIC_TELEGRAM_BOT}",
            htmlAttribute(process.env.PUBLIC_TELEGRAM_BOT || process.env.DIMTS_PUBLIC_TELEGRAM_BOT || ""),
          );
        this.emitFile({ type: "asset", fileName: "index.html", source: html });
      },
    },
    {
      name: "dimts-private-lit-metadata",
      enforce: "pre",
      resolveId(id) {
        return id === "virtual:Bridgely-lit-metadata"
          ? "\0Bridgely-lit-metadata"
          : null;
      },
      load(id) {
        if (id !== "\0Bridgely-lit-metadata") return null;
        // Reuse an existing host map for decorator interoperability, but never
        // create a property on window. All bundled Lit modules share this cell.
        return "const existing = globalThis.litPropertyMetadata; export const state = { value: existing instanceof WeakMap ? existing : new WeakMap() };";
      },
      transform(code, id) {
        if (
          !id.replaceAll("\\", "/").includes("/@lit/reactive-element/") ||
          !code.includes("litPropertyMetadata")
        )
          return null;
        // Lit 2.1 uses both an aliased global member and a bare global binding.
        // Redirect both reads and initialization; do not delete functional data
        // after class registration. This also covers the bundled decorators.
        const isolated = code.replace(
          /\b(?:[\w$]+\.)?litPropertyMetadata\b/gu,
          "BridgelyLitMetadata.value",
        );
        return {
          code: `import { state as BridgelyLitMetadata } from "virtual:Bridgely-lit-metadata";\n${isolated}`,
          map: null,
        };
      },
    },
    {
      name: "Bridgely-bootstrap-ui",
      resolveId(id) {
        return id === "virtual:Bridgely-bootstrap-ui"
          ? "\0Bridgely-bootstrap-ui"
          : null;
      },
      load(id) {
        if (id !== "\0Bridgely-bootstrap-ui") return null;
        const packs = loadPacks(
          fileURLToPath(new URL("../../locales", import.meta.url)),
        );
        return `export default ${JSON.stringify(packs.get("en")!.ui)};`;
      },
      generateBundle(_options, bundle) {
        const assets = new Set<string>(["bridgely-embed.js"]);
        const visit = (file: string) => {
          if (assets.has(file)) return;
          assets.add(file);
          const item = bundle[file];
          if (item?.type === "chunk")
            for (const imported of item.imports) visit(imported);
        };
        visit("Bridgely-widget.js");
        this.emitFile({
          type: "asset",
          fileName: "Bridgely-assets.json",
          source: JSON.stringify({ assets: [...assets] }),
        });
        const packs = loadPacks(
          fileURLToPath(new URL("../../locales", import.meta.url)),
        );
        this.emitFile({
          type: "asset",
          fileName: "Bridgely-locale-ui-sizes.json",
          source: JSON.stringify(
            Object.fromEntries(
              [...packs].map(([code, pack]) => [
                code,
                gzipSync(JSON.stringify(pack.ui)).byteLength,
              ]),
            ),
          ),
        });
        this.emitFile({
          type: "asset",
          fileName: "Bridgely-faq-sizes.json",
          source: JSON.stringify(
            Object.fromEntries(
              [...packs].map(([code, pack]) => {
                // Budget authored text even while publication is review-gated. This
                // build-only fixture does not approve or publish draft answers.
                const authored = Array.isArray(pack.faq)
                  ? (pack.faq as { q: string; a: string; source: string }[])
                  : [];
                const items = authored.map((entry, index) => ({
                  id: createHash("sha256")
                    .update(`${code}:${index}`)
                    .digest("hex"),
                  question: entry.q,
                  answer: entry.a,
                  citations: [
                    {
                      passageId: createHash("sha256")
                        .update(entry.source)
                        .digest("hex"),
                      label: entry.source,
                      url: `https://content.invalid/${encodeURIComponent(entry.source)}`,
                      sourceLang: code,
                      sourceType: "course",
                    },
                  ],
                }));
                const document = {
                  lang: code,
                  dir: pack.meta.dir,
                  contentVersion: createHash("sha256")
                    .update(JSON.stringify(authored))
                    .digest("hex"),
                  reviewedOn: pack.meta.reviewed_on,
                  items,
                };
                // Reserve additional compressed provenance bytes for each real
                // canonical label/URL, which are resolved only by the deployed API.
                return [
                  code,
                  gzipSync(JSON.stringify(document)).byteLength +
                    items.length * 256,
                ];
              }),
            ),
          ),
        });
      },
    },
  ],
  build: {
    manifest: true,
    lib: {
      entry: "src/loader.ts",
      formats: ["es"],
      fileName: () => "Bridgely-widget.js",
    },
    rollupOptions: {
      // Lazy help shares Lit with the entry. Permit internal exports instead
      // of creating a facade module and another serial download round trip.
      preserveEntrySignatures: "allow-extension",
      output: { chunkFileNames: "Bridgely-[name]-[hash].js" },
    },
  },
});
