export default {
  extends: ["stylelint-config-standard"],
  plugins: ["stylelint-use-logical"],
  rules: {
    "csstools/use-logical": "always",
  },
};
